#ifndef GRAFIKA_VJEZBE_GENERAL_UTILS_H
#define GRAFIKA_VJEZBE_GENERAL_UTILS_H

#include <vector>
#include <algorithm>
#include <fstream>

std::vector<float> linspace(float start_in, float end_in, size_t num_in)
{
    const float dx = (end_in - start_in) / (num_in - 1);
    std::vector<float> linspaced(num_in);
    int iter = 0;
    std::generate(linspaced.begin(), linspaced.end(),
                  [&] { return start_in + (iter++) * dx; });
    return linspaced;
}

/*a: poddiagonala, b: glavna dijagonala, c: nad dijagonala, d: rhs*/
std::vector<double> thomas_algorithm(const std::vector<double> &a, const std::vector<double> &b,
                                     const std::vector<double> &c, const std::vector<double> &d)
{
    size_t N = d.size();
    std::vector<double> f(N, 0.0);
    // Create the temporary vectors
    // Note that this is inefficient as it is possible to call
    // this function many times. A better implementation would
    // pass these temporary matrices by non-const reference to
    // save excess allocation and deallocation
    std::vector<double> c_star(N, 0.0);
    std::vector<double> d_star(N, 0.0);

    // This updates the coefficients in the first row
    // Note that we should be checking for division by zero here
    c_star[0] = c[0] / b[0];
    d_star[0] = d[0] / b[0];

    // Create the c_star and d_star coefficients in the forward sweep
    for (int i = 1; i < (int)N; i++)
    {
        double m = 1.0 / (b[i] - a[i-1] * c_star[i - 1]);
        c_star[i] = c[i-1] * m;
        d_star[i] = (d[i] - a[i-1] * d_star[i - 1]) * m;
    }

    // This is the reverse sweep, used to update the solution vector f
    for (int i = N - 1; i-- > 0;)
    {
        f[i] = d_star[i] - c_star[i] * d[i + 1];
    }
    return f;
}

// [ 0
std::vector<glm::vec3> read_points(const std::string& f_path)
{
    std::ifstream fin(f_path);

    std::vector<glm::vec3> pts;
    size_t pt_num;
    fin >> pt_num;
    pts.reserve(pt_num);
    for (size_t i = 0; i < pt_num; ++i)
    {
        double x, y, z;
        fin >> x >> y >> z;
        pts.push_back(glm::vec3(x, y, z));
    }

    return pts;
}
// 0 ]

#endif