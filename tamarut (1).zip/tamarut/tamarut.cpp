#include <iostream>
#include <vector>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "indexbuffer.h"
#include "renderer.h"
#include "shader.h"
#include "vertexarray.h"
#include "vertexbuffer.h"
#include "vertexbufferlayout.h"
#include "box.h"
#include "box_renderer.h"
#include "texture.h"

#include "pathconfig.h"

#include <algorithm>

unsigned int SCR_WIDTH = 1024;
unsigned int SCR_HEIGHT = 768;

constexpr float TIME_MULTIPLIER = 0.15f;
constexpr float CAMERA_ROTATE_SPEED = 0.1f;
constexpr float LIGHT_ROTATE_SPEED = 0.24f;

void framebuffer_size_callback(GLFWwindow *window, int width, int height);

float cubic_hermite(float t) // kubicna funkcija sa ubrzanjem i usporenjem
{
    return t * t * (3.0f - 2.0f * t);
}

struct Path
{
    glm::vec3 start, end;

    constexpr static float StopPoint = 0.45f;
    constexpr static float RestartPoint = 0.55f;

    glm::vec3 get_point(float t) const
    {
        if (t <= 0.45f)
            return glm::mix(start, end, cubic_hermite(t / StopPoint));
        if (t >= RestartPoint)
            return glm::mix(end, start, cubic_hermite((t - RestartPoint) / (1.0f - RestartPoint)));
        return end; // pauza nakon odmicanja, zadrzi poziciju u krajnjoj tocki
    }
};

struct Cube
{
    Texture normalMap;
    Path path;
    glm::vec3 color;

    Cube(const std::string &texture_path, const Path &path, const glm::vec3 &color, GLuint wrap = GL_REPEAT)
        : normalMap(texture_path, wrap), path(path), color(color) { }

};

void set_cubes(std::vector<Cube> &c)
{
    c.emplace_back(images_folder + "circles.png", Path { glm::vec3(0.5f, 0, -0.5f), glm::vec3(2, 0, -2) }, glm::vec3(1, 0, 0));
    c.emplace_back(images_folder + "spiral.png", Path { glm::vec3(-0.5f, 0, -0.5f), glm::vec3(-2, 0, -2) }, glm::vec3(0, 1, 0));
    c.emplace_back(images_folder + "stripes.png", Path { glm::vec3(-0.5f, 0, 0.5f), glm::vec3(-2, 0, 2) }, glm::vec3(0, 0, 1));
    c.emplace_back(images_folder + "projekt.png", Path { glm::vec3(0.5f, 0, 0.5f), glm::vec3(2, 0, 2) }, glm::vec3(1, 1, 0));

    c.emplace_back(images_folder + "wood_normal.png", Path { glm::vec3(0.5f, 1, -0.5f), glm::vec3(2, 1.5, -2) }, glm::vec3(1, 0, 1));
    c.emplace_back(images_folder + "toy_box_normal.png", Path { glm::vec3(-0.5f, 1, -0.5f), glm::vec3(-2, 1.5, -2) }, glm::vec3(0, 0, 0));
    c.emplace_back(images_folder + "waves.png", Path { glm::vec3(0.5f, 1, 0.5f), glm::vec3(2, 1.5, 2) }, glm::vec3(1, 1, 1));
    c.emplace_back(images_folder + "brickwall_normal.png", Path { glm::vec3(-0.5f, 1, 0.5f), glm::vec3(-2, 1.5, 2) }, glm::vec3(0, 1, 1));
}

int main()
{
    GLFWwindow *window;

    /* Initialize the library */
    if (!glfwInit()) return -1;

    glfwWindowHint(GLFW_SAMPLES, 4);// ovo nam za sada ne treba
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);// Za MacOS, tako kazu
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Tamarut zadaca", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    glfwSwapInterval(2);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    glewExperimental = true;// ovo nam treba za CORE Profile

    unsigned int err = glewInit();
    if (err != GLEW_OK)
    {
        std::cout << "error\n";
        return -1;
    }

    std::cout << glGetString(GL_VERSION) << std::endl;

    std::cout << "textures folder: " << images_folder << std::endl;
    std::cout << "shaders folder: " << shaders_folder << std::endl;

    const std::string fragment_path = shaders_folder + "frag.glsl";
    const std::string vertex_path = shaders_folder + "vert.glsl";

    Shader main_shader({ { GL_VERTEX_SHADER, vertex_path }, { GL_FRAGMENT_SHADER, fragment_path } });

    Box cube(glm::vec3(1, 0, 0));
    BoxRenderer cube_renderer(cube);

    Texture floor_texture(images_folder + "wood.png", GL_REPEAT);
    Texture floor_normal(images_folder + "wood_normal.png", GL_REPEAT);
    Texture white_texture(images_folder + "white.png", GL_REPEAT);
    std::vector<Cube> cubes;
    cubes.reserve(8);
    set_cubes(cubes);

    //const glm::mat4 floor_transform_matrix = glm::translate(glm::rotate(glm::scale(glm::mat4(1), glm::vec3(20)), glm::radians(-90.0f), glm::vec3(1, 0, 0)), glm::vec3(0, -0.5f, 0));

    const glm::mat4 floor_transform_matrix = glm::translate(glm::scale(glm::rotate(glm::translate(glm::mat4(1), glm::vec3(0, -0.5, 0)), glm::radians(-90.0f), glm::vec3(1, 0, 0)), glm::vec3(10)), glm::vec3(0, 0, -0.5f));

    float time_m = 0.f;
    float time_t = 0.f;
    float last_frame = glfwGetTime(), current_frame;


    glEnable(GL_DEPTH_TEST);
    while (!glfwWindowShouldClose(window))
    {
        current_frame = glfwGetTime();
        float time_delta = current_frame - last_frame;

        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
            glfwSetWindowShouldClose(window, true);

        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        {
            time_m = TIME_MULTIPLIER;
        }

        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        Renderer::clear();

        time_t += time_delta * time_m;
        if (time_t > 1)
        {
            time_m = 0;
            time_t = 0;
        }

        const glm::vec3 view_pos = (glm::mat3)glm::rotate(glm::mat4(1), current_frame * CAMERA_ROTATE_SPEED, glm::vec3(0, 1, 0)) * glm::vec3(-3.5, 2.1, 5.5);

        main_shader.bind();
        main_shader.setInt("diffuse_map", 0);
        main_shader.setInt("normal_map", 1);
        main_shader.setVec3("light_pos", (glm::mat3)glm::rotate(glm::mat4(1), current_frame * -LIGHT_ROTATE_SPEED, glm::vec3(0, 1, 0)) * glm::vec3(1.4, 1.5, 2.5));
        main_shader.setVec3("view_pos", view_pos);
        main_shader.setMat4("projection", glm::perspective(glm::radians(45.0f), (float)SCR_WIDTH / SCR_HEIGHT, 0.1f, 100.0f));
        main_shader.setMat4("view", glm::lookAt(view_pos, glm::vec3(0, 0.5, 0), glm::vec3(0, 1, 0)));

        main_shader.setMat4("transform", floor_transform_matrix);
        main_shader.setVec3("color", glm::vec3(1));
        floor_texture.bind(0);
        floor_normal.bind(1);
        // render floor using front face renderer
        Renderer::drawTriangles(cube_renderer.renderers[0]->va, cube_renderer.renderers[0]->ib, main_shader);

        white_texture.bind(0);
        for (const auto &cube : cubes)
        {
            const glm::mat4 cube_transform = glm::translate(glm::mat4(1), cube.path.get_point(time_t));
            main_shader.setMat4("transform", cube_transform);
            main_shader.setVec3("color", cube.color);
            cube.normalMap.bind(1);
            for (const auto &cr : cube_renderer.renderers)
                Renderer::drawTriangles(cr->va, cr->ib, main_shader);
        }

        last_frame = current_frame;

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow *window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and
    // height will be significantly larger than specified on retina displays.
    SCR_WIDTH = width;
    SCR_HEIGHT = height;
    glViewport(0, 0, width, height);
}
